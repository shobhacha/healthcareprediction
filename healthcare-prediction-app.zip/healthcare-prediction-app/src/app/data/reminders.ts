// src/app/data/reminders.ts
export const REMINDERS = [
    {
      id: 1,
      title: 'Blood Pressure Medication',
      description: 'Consume one pill in the morning.', 
      time: '08:00 AM',
      frequency: 'Daily'
    },
    {
      id: 2,
      title: 'Doctor\'s Appointment',
      description: 'Appointment with Dr. Smith at his clinic.',
      time: '10:00 AM',
      date: '2024-06-30'
    },
    {
      id: 3,
      title: 'Exercise',
      description: '30 minutes of cardio exercise.',
      time: '06:00 PM',
      frequency: 'Daily'
    },
    // Add more reminders as needed

    {
    id: 4,
    title: 'Diet',
    description: 'Eat seasonal and healthy fruits.',
    time:'12:00 pm',
    frequency:'Daily',
    },

    {
      id: 5,
      title: 'Sugar Test',
      description: 'Sugest test at home',
      time:'14:00 pm',
      frequency:'Daily',
      },
  ];
  