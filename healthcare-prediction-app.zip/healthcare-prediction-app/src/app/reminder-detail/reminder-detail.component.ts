import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { REMINDERS } from '../data/reminders';

@Component({
  selector: 'app-reminder-detail',
  templateUrl: './reminder-detail.component.html',
  styleUrl: './reminder-detail.component.css'
})
export class ReminderDetailComponent implements OnInit {
  reminder: any;

  constructor(private route: ActivatedRoute) {}

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.reminder = REMINDERS.find(reminder => reminder.id === id);
  }
}