// In a mock-data.ts file
export const conditions = [
    { id: 1, name: 'Condition 1' },
    { id: 2, name: 'Condition 2' },
    // Add more as needed
  ];
  
  export const predictions = [
    { conditionId: 1, prediction: 'High risk' },
    { conditionId: 2, prediction: 'Low risk' },
    // Add more as needed
  ];
  