import { TestBed } from '@angular/core/testing';

import { InputpredictionService } from './inputprediction.service';

describe('InputpredictionService', () => {
  let service: InputpredictionService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(InputpredictionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
