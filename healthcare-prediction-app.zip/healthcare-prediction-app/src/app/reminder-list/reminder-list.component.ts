import { Component, OnInit } from '@angular/core';
import { REMINDERS } from '../data/reminders';

@Component({
  selector: 'app-reminder-list',
  templateUrl: './reminder-list.component.html',
  styleUrl: './reminder-list.component.css'
})
export class ReminderListComponent implements OnInit {
  reminders = REMINDERS;

  constructor() {}

  ngOnInit(): void {}
}