import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class InputpredictionService  {private conditionsList = [
  { id: 1, name: 'Condition A' },
  { id: 2, name: 'Condition B' },
  { id: 3, name: 'Condition C' }
  // Add more conditions as needed
];

getConditionsList() {
  return this.conditionsList;
}

predict(conditionId: number): string {
  // Simulate prediction logic based on conditionId
  switch (conditionId) {
    case 1:
      return 'High risk predicted for Condition A';
    case 2:
      return 'Low risk predicted for Condition B';
    case 3:
      return 'Moderate risk predicted for Condition C';
    default:
      return 'No prediction available';
  }
}
}
